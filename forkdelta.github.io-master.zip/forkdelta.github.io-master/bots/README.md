See [the bots repository](https://github.com/etherdelta/bots).
